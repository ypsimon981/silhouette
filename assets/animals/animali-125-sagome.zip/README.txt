SET ANIMALI — 125 sagome

Tracciati vettoriali estratti dalla foto fornita IMG_0602.webp.
Ogni file SVG usa viewBox 0 0 100 100 e mantiene le proporzioni.
Il catalogo JSON contiene nomi descrittivi, categoria, path e riquadro di origine.
sourceEdge=true segnala una figura tagliata dal bordo della foto: non selezionata nelle partite.
I nomi delle specie sono descrittivi, non una classificazione zoologica verificata.
Questo pacchetto non attribuisce diritti aggiuntivi sull’immagine sorgente.
